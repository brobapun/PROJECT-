 birdImg=new ImageIcon(getClass().getResource("./bird.jpg")).getImage();
    //     upbamboImg=new ImageIcon(getClass().getResource("./upbambo.jpg")).getImage();
    //    backgroundImg=new ImageIcon(getClass().getResource("./downbambo.jpg")).getImage();